done = False
while not done:
    try:
        firstTerm = float(input("First Term"))
        secondTerm = float(input("Second Term"))
        done = True
    except ValueError:
        done = False


ratio = secondTerm / firstTerm
if ratio < 1 and ratio > -1:
    converge = firstTerm/(1-ratio)
    print("Ratio is: " + str(ratio) + " The series converges too: " + str(converge))

else:
    print("Ratio is: " + str(ratio) + " The series does not converge.")
