import numpy as np
import pandas as pd
import time

wordList = pd.read_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\word.csv')

wordCSV = pd.DataFrame(columns=np.array(['words', 'removedWords']))
wordCSV.to_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\wordRemoved.csv')

letterOne = None
letterTwo = None
letterThree = None
letterFour = None
letterFive = None





def letterMatch(currentWord, solutionWord):
    if solutionWord[0] == currentWord[0]:
        letterOne = 2
    elif currentWord[0] in solutionWord:
        letterOne = 1
    else:
        letterOne = 0


    if solutionWord[1] == currentWord[1]:
        letterTwo = 2
    elif currentWord[1] in solutionWord:
        letterTwo = 1
    else:
        letterTwo = 0

    if solutionWord[2] == currentWord[2]:
        letterThree = 2
    elif currentWord[2] in solutionWord:
        letterThree = 1
    else:
        letterThree = 0


    if solutionWord[3] == currentWord[3]:
        letterFour = 2
    elif currentWord[3] in solutionWord:
        letterFour = 1
    else:
        letterFour = 0


    if solutionWord[4] == currentWord[4]:
        letterFive = 2
    elif currentWord[4] in solutionWord:
        letterFive = 1
    else:
        letterFive = 0

    return letterOne, letterTwo, letterThree, letterFour, letterFive


def removedWords(currentWord, letterMatch):
    nonWords = 0
    for word in wordList.words:
        y = 0
        done = False
        for match in letterMatch:
            if not done:
                if match == 0:
                    if currentWord[y] in word:
                        nonWords = nonWords + 1
                        done = True
                elif match == 1:
                    if currentWord[y] not in word:
                        nonWords = nonWords + 1
                        done = True
                elif match == 2:
                    if currentWord[y] != solutionWord[y]:
                        nonWords = nonWords + 1
                        done = True
            y = y + 1
    return nonWords



x = 0
removed = 0
word = 'crane'
startDT = time.time()
x = x + 1
removed = 0
for solutionWord in wordList.words:
    match = letterMatch(currentWord=word, solutionWord=solutionWord)
    removed = removed + removedWords(currentWord=word, letterMatch=match)
endDT = time.time()
print("Current Word: " + str(word) + " Number of words Removed: " + str(removed) + " Time taken: " + str(endDT - startDT))
wordCSV.loc[x] = np.array([word, removed])
wordCSV.to_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\wordRemoved.csv')