# Find the most common letter in each postion of the word.
import pandas as pd # Library used for sorting through CSV files.
wordList =pd.read_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\word.csv')
from astropy.table import Table
allFreq1 = {}
allFreq2 = {}
allFreq3 = {}
allFreq4 = {}
allFreq5 = {}
letterList1 = []
letterList2 = []
letterList3 = []
letterList4 = []
letterList5 = []

columns = ['letter 1', 'letter 2', 'letter 3', 'letter 4', 'letter 5']
rows = range(26)

for word in wordList.words: # This iterates over the course of each word in our ~3200 words
    x = 0
    for letter in word: # This iterates over each letter in our 5 letter words
        x = x + 1
        if x == 1:
            if letter in allFreq1:
                allFreq1[letter] += 1
            else:
                allFreq1[letter] = 1

        if x == 2:
            if letter in allFreq2:
                allFreq2[letter] += 1
            else:
                allFreq2[letter] = 1

        if x == 3:
            if letter in allFreq3:
                allFreq3[letter] += 1
            else:
                allFreq3[letter] = 1

        if x == 4:
            if letter in allFreq4:
                allFreq4[letter] += 1
            else:
                allFreq4[letter] = 1

        if x == 5:
            if letter in allFreq5:
                allFreq5[letter] += 1
            else:
                allFreq5[letter] = 1

for w in sorted(allFreq1, key=allFreq1.get, reverse=True): # Than this sorts through the words and orders them
    # print(w, allFreq1[w])
    letterList1.append(w + " " + str(allFreq1[w]))

for w in sorted(allFreq2, key=allFreq2.get, reverse=True): # Than this sorts through the words and orders them
    # print(w, allFreq2[w])
    letterList2.append(w + " " + str(allFreq2[w]))

for w in sorted(allFreq3, key=allFreq3.get, reverse=True): # Than this sorts through the words and orders them
    # print(w, allFreq3[w])
    letterList3.append(w + " " + str(allFreq3[w]))

for w in sorted(allFreq4, key=allFreq4.get, reverse=True): # Than this sorts through the words and orders them
    # print(w, allFreq4[w])
    letterList4.append(w + " " + str(allFreq4[w]))

for w in sorted(allFreq5, key=allFreq5.get, reverse=True): # Than this sorts through the words and orders them
    # print(w, allFreq5[w])
    letterList5.append(w + " " + str(allFreq5[w]))

letterList5.append('q 0')
letterList5.append('j 0')


t = Table([letterList1, letterList2, letterList3, letterList4, letterList5], names=('letter 1', 'letter 2', 'letter 3', 'letter 4', 'letter 5'))
print(str(t))
# t.show_in_browser()

print(allFreq2)