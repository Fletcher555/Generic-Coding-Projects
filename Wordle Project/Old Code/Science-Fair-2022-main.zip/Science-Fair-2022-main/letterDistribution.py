import pandas as pd # Library used for sorting through CSV files.
import matplotlib.pyplot as plt
wordList =pd.read_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\word.csv') # Reads the CSV File where the words are
all_freq = {} # This defines an open dict type variable with no values which we than fill.
x = 0
letterList = []
countList = []
percentList = []
for word in wordList.words: # This iterates over the course of each word in our ~3200 words
    for letter in word: # This iterates over each letter in our 5 letter words
        if letter in all_freq: # We than check to see if the letter is already in our dict variable
            all_freq[letter] += 1 # If it is we add 1 to its value
        else: # If its not
            all_freq[letter] = 1 # We add the letter to our list and set its value to 1
for w in sorted(all_freq, key=all_freq.get, reverse=True): # Than this sorts through the words and orders them
    # print(w, all_freq[w])
    letterList.append(w)
    countList.append(all_freq[w])
letterSum = sum(countList)
for x in countList:
    percentList.append(x/letterSum)


print(countList)
# Plots the bar chart for the letter Distribution
plt.bar(letterList, percentList, color='red')
plt.title('Letter distribution', fontsize=16)
plt.xlabel('Letter', fontsize=14)
plt.ylabel('Count', fontsize=14)
plt.show()