from ComparisonFunction import matchScript
from numpy import testing



testing.assert_array_equal(matchScript('tstts', 'sissy'), [0, 1, 0, 0, 1], err_msg='', verbose=True)
testing.assert_array_equal(matchScript('reese', 'erane'), [1, 1, 0, 0, 2], err_msg='', verbose=True)
testing.assert_array_equal(matchScript('sails', 'rails'), [0, 2, 2, 2, 2], err_msg='', verbose=True)
testing.assert_array_equal(matchScript('erane', 'reese'), [1, 1, 0, 0, 2], err_msg='', verbose=True)
testing.assert_array_equal(matchScript('sissy', 'tstts'), [1, 0, 1, 0, 0], err_msg='', verbose=True)

