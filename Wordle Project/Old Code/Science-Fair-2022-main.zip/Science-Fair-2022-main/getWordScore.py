import numpy as np
import pandas as pd

wordList = pd.read_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\word.csv')
wordCSV = pd.DataFrame(columns=np.array(['Words', 'yellowScore', 'greenScore', 'sumOne']))
wordCSV.to_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\wordScore.csv')
x = 0


def getScore(currentWord, x):
    greenScore = 0
    yellowScore = 0
    for word in wordList.words:
        y = 0
        for letter in word:

            if letter in currentWord:
                if currentWord[y] == letter:
                    greenScore += 1
                else:
                    yellowScore += 1
            y += 1
    wordCSV.loc[x] = np.array([currentWord, yellowScore, greenScore, (greenScore + yellowScore)])
    wordCSV.to_csv(r'C:\Users\Milo\Documents\PythonPandasFiles\wordScore.csv')



for word in wordList.words:
    print(word)
    getScore(currentWord=word, x=x)
    x += 1
